<html>
<head> 
<link href="editprofile1.css" rel="stylesheet" type="text/css" />

<style type="text/css">
	#a1,#a2,#a3,#a4,#a5,#a6
	{
		width:850px;
		background-color:#CCC;
		font-family:"Arial Black", Gadget, sans-serif;
		color:#336;
		background-size:contain;
		text-align:left;
		border-radius:5px 5px 0px 0px;
		margin-bottom:0px;
		cursor:pointer;
	}
	#d1,#d2,#d3,#d5,#del1,#del2,#del3,#del5,#p1
	{
		width:80px;
		//background-color:#CCC;
		font-family:"Arial Black", Gadget, sans-serif;
		color:#03F;
		background-size:contain;
		text-align:left;
		//border-radius:5px 5px 0px 0px;
		margin-bottom:0px;
		cursor:pointer;
	}
	#tab1,#tab2,#tab3,#tab4,#tab5,#tab6
	{
		width:845px;
		padding:5px;
		border:1px solid #069;
		border-radius:0px 0px 5px 5px;
		font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
		margin-top:0px;
	}
	#r1,#r2,#r3,#r5
	{
		//width:80px;
		padding:5px;
		border:1px solid #069;
		border-radius:0px 0px 5px 5px;
		font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
		margin-top:0px;
	}
</style>
<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript">
	$(document).ready(function(e) {
		$("#tab1").hide();
		$("#tab2").hide();
		$("#tab3").hide();
		$("#tab4").hide();
		$("#tab5").hide();
		$("#tab6").hide();
		$("#r1").hide();
		$("#r2").hide();
		$("#r3").hide();
		$("#r5").hide();
        $("#a1").click(function(){
		});
		
		$("#a1").click(function(){
			$("#tab1").slideToggle(2000);	
		});
		$("#a2").click(function(){
			$("#tab2").slideToggle(800);	
		});
		
		$("#a3").click(function(){
			$("#tab3").slideToggle(800);	
		});
		
		$("#a4").click(function(){
			$("#tab4").slideToggle(800);	
		});
		
		$("#a5").click(function(){
			$("#tab5").slideToggle(800);	
		});
		
		$("#a6").click(function(){
			$("#tab6").slideToggle(800);	
		});
		
		$("#d1").click(function(){
			$("#r1").slideDown(800);	
		});
		
		$("#p1").click(function(){
			$("#r1").slideUp(800);	
		});
		
		$("#d2").click(function(){
			$("#r2").slideDown(800);	
		});
		
		$("#p2").click(function(){
			$("#r2").slideUp(800);	
		});
		
		$("#d3").click(function(){
			$("#r3").slideDown(800);	
		});
		
		$("#p3").click(function(){
			$("#r3").slideUp(800);	
		});
		
		$("#d5").click(function(){
			$("#r5").slideDown(800);	
		});
		
		$("#p5").click(function(){
			$("#r5").slideUp(800);	
		});
		
    });

	
</script>



</head>

<body>

<div id="main">

<div id="wrapper">

 <div id="banner">
 
 </div>

  <div id="middle">
 
  <div id="content">
  <h2> Welcome <?php ?> to your profile</h2>
  <p>&nbsp;</p>
	<div id="sqrt">
    </div>  
    <h1 id="a1">Name</h1>
	<table id="tab1" width="850" border="1">
	  <tr>
	    <td>First Name</td>
	    <td>Middle Name</td>
	    <td>Last Name</td>
	    <td id="d1">Edit</td>
	    </tr>
	  <tr id="r1">
	    <td><?php ?></td>
	    <td><?php ?></td>
	    <td><?php ?></td>
	    <td id="del1"><p id="p1"/>Cancel/Delete</td>
	    </tr>
	  </table>
	<h1 id="a2">Date of Birth</h1>
    	<table id="tab2" width="850" border="1">
	  <tr>
	    <td>Date</td>
	    <td id="d2">Edit</td>
	    </tr>
	  <tr id="r2">
	    <td><?php ?></td>
	    <td id="del2"><p id="p2"/>Cancel/Delete</td>
	    </tr>
	  </table>
    <h1 id="a3">Date of Place</h1>
	 
    <table id="tab3" width="850" border="1">
	  <tr>
	    <td>City</td>
	    <td>State</td>
	    <td id="d3">Edit</td>
	    </tr>
	  <tr id="r3">
	    <td><?php ?></td>
	    <td><?php ?></td>
	    <td id="del3"><p id="p3"/>Cancel/Delete</td>
	    </tr>
	  </table>
      
	<h1 id="a4">Phone</h1>
    <p id="tab4">phn</p>
	<h1 id="a5">Address</h1>
    <table id="tab5" width="850" border="1">
	  <tr>
	    <td>Address</td>
	    <td>City</td>
	    <td>Pin Code</td>
        <td>State</td>
	    <td id="d5">Edit</td>
	    </tr>
	  <tr id="r5">
	    <td><?php ?></td>
	    <td><?php ?></td>
	    <td><?php ?></td>
        <td><?php ?></td>
	    <td id="del5"><p id="p5"/>Cancel/Delete</td>
	    </tr>
	  </table>
	<h1 id="a6">Academics</h1>
    <p id="tab6">acd</p>
     
        
  </div>
</div>
    
  <div id="bottom"></div>
   
  </div>
     
  </div> 


</body>
</html>