<?php
$cn=mysql_connect("localhost","root","123");
if(!$cn)
{
	echo "Unable to connect";
	die();
}
$db=mysql_select_db("profilo_db",$cn);
if(!$db)
{
	echo "Database does not exist";
	die();
}
?>