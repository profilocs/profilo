
<?php
//delete user [dot] php
if(isset($_GET["admin"]))
{
	if ($_GET["admin"]=="sushil01796")
	{
		echo "you are admin (y)<br>";
		if (isset($_GET["user"]))
		{
			echo "selected user id is ".$_GET["user"]."<br>Are you Sure you want to delete this user and <strong><h3> never ever get back </h3></strong> recovered...";
			echo "<br><br><button name='sure1' type='submit' action=''>Yes i am sure delete this user (".$_GET["user"].")!!</button>";
			echo "<button>OO00Psss Dont delete this!!</button>";
		}
		else
		{
			echo "but no user selected";
		}
		
	}
	else
	{
		echo "Invalid admin";
	}
	
}
else
{
	echo "you must be admin";
}
?>