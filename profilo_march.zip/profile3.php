<html>
    <head>
	  <link href="profile.css" rel="stylesheet" type="text/css" />
	  <script type="text/javascript" src="pro_script.js"></script>
	  <title>Profilo : soon</title>
    </head>
    <body id="body1" style="overflow-y: hidden;" onload="docLoad('main')">
	  <div id="main" onscroll="fScroll(this);" style="overflow-y: auto;">
	  <div id="wrapper">
		<div id="banner">
		</div>
		<div id="middle">
		    <div id="content">
			  <?php
				require_once "mylibrary.php";
				require_once "functions.php";
				
				
				session_start();
				//echo "----------".$_SESSION["logged"];
				//$_SESSION["logged"]="out";
				if(!isset($_SESSION["logged"]))
				{
					$_SESSION["logged"]="out";
				}
				
				if ($_SESSION["logged"]=="out")
				{
					if(isset($_POST["LogInS"]))
					{
						echo "loginsubmitted";
						if(login($_POST["uname"],$_POST["pswd"])!=0)
						{
							$_SESSION["logged"]="in";
				
							$_SESSION["uid"] = login($_POST["uname"],$_POST["pswd"]);
							$loggedInUserId = $_SESSION["uid"];
							echo "---login success";
							echo "---logged in user".$_SESSION["uid"];
				
						}
						else
						{
							echo "---login failure";
						}
					}
				}
				if($_SESSION["logged"]=="in")
				{
					$loggedInUserId = $_SESSION["uid"];
					//dher saare if if if aayenge...
					// saari edit delete requests yhi aayngi
					if(isset($_POST["editnameS"])){
						echo "edit name requested";
						echo "edit submit success.. try refresh if result not appear";
						edit($_REQUEST["entryid"],'name',$_REQUEST);
					}
					if (isset($_POST["childS"])) {
						updateentry($loggedInUserId,$_REQUEST["shtype"],$_REQUEST["vis"],$_REQUEST);
					}
					if (isset($_POST["editaS"])) {
						edit($_REQUEST["eid"],$_REQUEST["shtype"],$_REQUEST);
					}
					if (isset($_POST["hideS"])) {
						togglevis($_REQUEST["eid"]);
					}
					if (isset($_POST["unhideS"])) {
						togglevis($_REQUEST["eid"]);
					}					
					if (isset($_POST["LogOutS"])) {
						echo "logoutsubmitted";
						$_SESSION["logged"]="out";
					}
				}
				
				
				
				
				
				if(isset($_GET["user"]))
				{
				$uid=$_GET["user"];
				if(userExists($uid))
				{
					$editor=0;
					if ($_SESSION["logged"]=="in")
					{
						if ($uid==$loggedInUserId)
						{
							$editor=1;
							echo "edit allowed";
						}
					}
				
					$fullname = fetchkey('name',$uid,1);
					echo "size name ".sizeof($fullname);
					//echo json_encode($fullname);
					$row = $fullname[0];

					
			   echo "<h4> Name: ".$row["initial"]." ".$row["fname"]." ".$row["mname"]." ".$row["lname"]."</h4>";

				$nameps= array('','','','','','','');
				if ($editor) {
						$nameps = $row;
						echo "<p onClick=\"Show('editnameform')\" style='cursor: pointer;'>Show Edit name form</p><div id='editnameform_container'></div>";
				}
				
				echo "<br>logged status--".$_SESSION["logged"];
				if($_SESSION["logged"]=="out")
				{
					echo "<h5 onClick=\"Show('loginform')\" style='cursor: pointer;'>Show Login Form</h5><div id='loginform_container'></div>";
				}
				else if($_SESSION["logged"]=="in")
				{
					echo "<form method='post' id='logoutform'><input name='LogOutS' type='submit' value='Log Out'></form>";
				}
				//$h1=array();
				$h1 = fetchg('headings',0);
				for($i=3;$i<sizeof($h1);$i++)
				{
					echo "<p>";
					echo "<br>".$h1[$i]["name"]; 
					echo "</p><br>";
			  
				$h2 = fetchg('subheadings',$i+1);
				$j=0;
				
				while($j<sizeof($h2))
				{
					echo "<table border='1'>";
					//if (sizeof($h2)>1)
					//{
						echo "<thead><td>Sr.</td><td>";
						if ($editor==1)
						{
							$key[$j]=fetchkey($h2[$j]["name"],$uid,0);
						}
						else
						{
							$key[$j]=fetchkey($h2[$j]["name"],$uid,1);
						}
						

						echo (sizeof($key[$j])==0) ? "No Entries yet!! " : ((sizeof($key[$j])==1) ? "1 Entry" : sizeof($key[$j])." Entries");
						if($editor==1)
							echo " Add one now..<input onclick =\"addedit('add','add_".strtolower(substr($h2[$j]["name"], 0, 4))."')\" type='Button' name='plusemail' id='plusemail' value='+'' />";
						echo "</td>";
						if($editor==1)
							echo "<td>Actions</td>";
						echo "</thead>";
					//}
						
					echo "<tbody>";
					
					//echo "sizeof".sizeof($key[$j]);
					//echo "<br>".json_encode($key);
					//echo "<tr>";
					for($k=0;$k<sizeof($key[$j]);$k++)
					{
						if($h2[$j]["name"]=="dob")
					{
						$h2[$j]["name"]="Date of Birth";
					}
					else if($h2[$j]["name"]=="pob")
					{
						$h2[$j]["name"]="Place of Birth";
						//$asd = 
					}
					else if($h2[$j]["name"]=="phone")
					{
						$h2[$j]["name"]="Phone Number";
					}
						//echo $h2[$j]["name"].":::--";
						echo "<tr><td>".($k+1).".</td><td>".json_encode($key[$j][$k])."</td>";
						//if editor on then actions actions actions actions actions actions actions actions actions actionsactions actionsactionsactionsactions 
						if($editor==1)
						{
							
							echo "<td><button name='editS' value='Edit' onClick=\"addedit('edit',['".$key[$j][$k]["entryid"]."','".$h2[$j]["name"]."','".$key[$j][$k]["value"]."'])\">Edit</button> ";
							$len=sizeof($key[$j][$k]);
							//echo "lrnnnngth".$len;
							if ($key[$j][$k][3]["visible"]==1)
							{
								echo "| <form method='post' id='hideform'><input type='hidden' name='eid' value='".$key[$j][$k]["entryid"]."'><input name='hideS' type='submit' value='Hide'></form>";
							}
							else
							{
								echo " | <form method='post' id='unhideform'><input type='hidden' name='eid' value='".$key[$j][$k]["entryid"]."'><input name='unhideS' type='submit' value='Unhide'></form>";
							}
							echo " </td>";
						}//addedit('edit',['".$key[$j][$k]["id"]."','."$h2[$j]["name"]."'])
						echo "</tr>";
					}
					
					//echo $j."hgfckjhc ";
					$char4h=substr($h1[$i]["name"], 0, 4);
					if($editor==1&&($char4h=='Memb'||$char4h=='Edit'||$char4h=='Work'||$char4h=='Spon'||$char4h=='Pape'||$char4h=='Trai'||$char4h=='Expe'||$char4h=='Subj'||$char4h=='Refe'||$char4h=='Unde'||$char4h=='Jobs'))
					{
						echo "<tr><td>".($k+1).".</td><td><form method='post' id='add_".$h2[$j]["name"]."' style='display:none;'><input type='hidden' name='shtype' value='".$h2[$j]["name"]."'><input type='text' name='data' size='100%'><input type='radio' name='vis' value='1' checked>show<input type='radio' name='vis' value='0'>hide<input type='submit' name='childS' value='save'><input type='button' onClick=\"addchild('add_".strtolower(substr($h2[$j]["name"], 0, 4))."')\" value='cancel'></form>";
						echo "<div id='".$h2[$j]["name"]."form_container'></div></td></tr>";
					}
					echo "</tbody></table>";
					$j++;
				}
				

				}
				
				}
				else
				{
					echo "No Such User Exixts";
				}
				}
				else
				{
				echo "Go Back and Select a User";
				}
				?>
			  		    </div>
		    <div id="bottom"></div>
		</div>
	  </div>
    </body>
</html>