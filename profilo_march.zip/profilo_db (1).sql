-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2016 at 03:19 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `profilo_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic`
--

CREATE TABLE IF NOT EXISTS `academic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam` varchar(20) NOT NULL,
  `year` varchar(12) DEFAULT NULL,
  `board_uni` varchar(40) DEFAULT NULL,
  `result` varchar(40) NOT NULL,
  `remarks` varchar(40) DEFAULT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `academic`
--

INSERT INTO `academic` (`id`, `exam`, `year`, `board_uni`, `result`, `remarks`, `entryid`) VALUES
(1, 'ghjd', 'dfghsh', '', '', '', 37),
(6, 'qwee', '', '', '', '', 42),
(12, 'we', '2014-09-09', '', '234', '', 49),
(15, 'we', '2014-09-09', 'rtu', 'p', '234', 53),
(17, 'sdf', '1199-09-09', 'zdf', 'p', 'zdf', 55),
(18, 'sdf', '1199-09-09', 'zdf', 'p', 'zdf', 56),
(19, 'rfg', '1990-09-09', 'ew', 'p', 'j', 57),
(20, '', '', '', '', '', 58);

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line1` varchar(30) NOT NULL,
  `line2` varchar(30) DEFAULT NULL,
  `city` varchar(20) NOT NULL,
  `pincode` varchar(6) DEFAULT NULL,
  `state` varchar(20) NOT NULL DEFAULT 'Rajasthan',
  `type` varchar(10) NOT NULL DEFAULT 'Permanent',
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `line1`, `line2`, `city`, `pincode`, `state`, `type`, `entryid`) VALUES
(1, 'asd', 'jnjk', '', '87', '', '', 26),
(2, 'asd', 'jnjk', '89', '87', 'raa', 'perma', 32);

-- --------------------------------------------------------

--
-- Table structure for table `conf`
--

CREATE TABLE IF NOT EXISTS `conf` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `dob`
--

CREATE TABLE IF NOT EXISTS `dob` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` date NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `dob`
--

INSERT INTO `dob` (`id`, `value`, `entryid`) VALUES
(1, '0000-00-00', 23),
(2, '0000-00-00', 25),
(3, '0000-00-00', 29),
(4, '2015-12-01', 62);

-- --------------------------------------------------------

--
-- Table structure for table `edit`
--

CREATE TABLE IF NOT EXISTS `edit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `edit`
--

INSERT INTO `edit` (`id`, `value`, `entryid`) VALUES
(1, 'edit work 1', 77);

-- --------------------------------------------------------

--
-- Table structure for table `entries`
--

CREATE TABLE IF NOT EXISTS `entries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=78 ;

--
-- Dumping data for table `entries`
--

INSERT INTO `entries` (`id`, `uid`, `type`, `visible`, `time`) VALUES
(13, 1, 'name', 1, '2016-01-11 07:20:08'),
(14, 1, 'name', 1, '2016-01-11 07:20:08'),
(15, 1, 'name', 1, '2016-01-11 07:20:08'),
(16, 1, 'name', 1, '2016-01-11 07:20:08'),
(17, 1, 'name', 1, '2016-01-11 07:20:08'),
(18, 1, 'name', 1, '2016-01-11 07:20:08'),
(19, 1, 'phone', 1, '2016-01-16 10:40:24'),
(20, 1, 'pob', 1, '2016-01-11 07:20:08'),
(21, 2, 'name', 1, '2016-01-11 07:20:08'),
(22, 2, 'pob', 1, '2016-01-13 10:58:55'),
(24, 2, 'email', 1, '2016-01-11 07:20:08'),
(26, 2, 'address', 1, '2016-01-11 07:20:08'),
(27, 2, 'name', 1, '2016-01-11 07:20:08'),
(28, 2, 'pob', 0, '2016-01-11 07:20:08'),
(30, 2, 'email', 1, '2016-01-11 07:20:08'),
(31, 2, 'phone', 1, '2016-01-13 11:19:08'),
(32, 2, 'address', 1, '2016-01-11 07:20:08'),
(33, 3, 'academic', 0, '2016-01-12 10:09:15'),
(48, 3, 'academic', 1, '2016-01-12 10:27:34'),
(49, 3, 'academic', 1, '2016-01-12 10:29:34'),
(50, 3, 'academic', 1, '2016-01-12 10:31:41'),
(51, 3, 'academic', 1, '2016-01-12 10:33:49'),
(52, 3, 'phone', 1, '2016-01-12 10:36:26'),
(53, 3, 'academic', 1, '2016-01-12 10:36:26'),
(54, 3, 'academic', 1, '2016-01-12 10:36:52'),
(55, 3, 'academic', 1, '2016-01-12 10:40:09'),
(56, 3, 'academic', 0, '2016-01-12 10:42:13'),
(57, 4, 'academic', 1, '2016-01-12 10:43:44'),
(58, 3, 'academic', 1, '2016-01-12 10:53:44'),
(59, 1, 'onlinep', 1, '2016-01-12 11:21:19'),
(60, 1, 'onlinep', 1, '2016-01-16 10:51:47'),
(61, 1, 'onlinep', 0, '2016-01-19 14:12:58'),
(62, 2, 'dob', 1, '2016-01-13 10:10:25'),
(63, 2, 'phone', 1, '2016-01-13 11:19:53'),
(64, 1, 'memb', 1, '2016-01-16 10:16:19'),
(65, 2, 'memb', 1, '2016-01-18 07:36:50'),
(66, 2, 'memb', 1, '2016-01-18 12:04:01'),
(67, 2, 'work', 1, '2016-01-18 12:33:09'),
(68, 2, 'work', 1, '2016-01-18 12:40:51'),
(69, 2, 'jour', 1, '2016-01-18 12:47:03'),
(70, 1, 'memb', 1, '2016-01-19 14:15:59'),
(71, 1, 'memb', 0, '2016-01-19 13:09:36'),
(72, 1, 'memb', 0, '2016-01-19 14:16:33'),
(73, 1, 'memb', 1, '2016-01-18 14:16:34'),
(74, 1, 'memb', 1, '2016-01-18 14:17:02'),
(75, 1, 'refe', 1, '2016-01-18 14:26:25'),
(76, 1, 'jour', 1, '2016-01-19 04:55:09'),
(77, 1, 'edit', 1, '2016-01-19 12:49:54');

-- --------------------------------------------------------

--
-- Table structure for table `expe`
--

CREATE TABLE IF NOT EXISTS `expe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `jour`
--

CREATE TABLE IF NOT EXISTS `jour` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `jour`
--

INSERT INTO `jour` (`id`, `value`, `entryid`) VALUES
(1, 'Sharma', 69),
(2, 'paper 11 test', 76);

-- --------------------------------------------------------

--
-- Table structure for table `list_headings`
--

CREATE TABLE IF NOT EXISTS `list_headings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT 'Heading: custom',
  `descri` text,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `status` varchar(20) NOT NULL DEFAULT 'approved',
  `count_sh` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `list_headings`
--

INSERT INTO `list_headings` (`id`, `name`, `descri`, `visible`, `status`, `count_sh`) VALUES
(1, 'Personal Details', NULL, 1, 'approved', 0),
(2, 'Contact Mediums', NULL, 1, 'approved', 0),
(3, 'Academics', NULL, 1, 'approved', 0),
(4, 'Membership/ Fellowship of Professional Societies/ Bodies', NULL, 1, 'approved', 0),
(5, 'Editorial Work', NULL, 1, 'approved', 0),
(6, 'Workshop/Conference Organized', NULL, 1, 'approved', 0),
(7, 'Sponsered Projects', NULL, 1, 'approved', 0),
(8, 'Paper Presented/Published/Accepted', NULL, 1, 'approved', 0),
(9, 'Training Program Attended', NULL, 1, 'approved', 0),
(10, 'Experience & Awards', NULL, 1, 'approved', 0),
(11, 'Subjects Of Interests', NULL, 1, 'approved', 0),
(12, 'References', NULL, 1, 'approved', 0),
(13, 'Under Supervision', NULL, 1, 'approved', 0),
(14, 'Jobs/Services', NULL, 1, 'approved', 0);

-- --------------------------------------------------------

--
-- Table structure for table `list_subheadings`
--

CREATE TABLE IF NOT EXISTS `list_subheadings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT 'Heading: custom',
  `descri` text,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `status` varchar(20) NOT NULL DEFAULT 'approved',
  `count_sh` int(11) DEFAULT '0',
  `attached` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `list_subheadings`
--

INSERT INTO `list_subheadings` (`id`, `name`, `descri`, `visible`, `status`, `count_sh`, `attached`) VALUES
(1, 'dob', NULL, 1, 'approved', 0, 1),
(2, 'pob', NULL, 1, 'approved', 0, 1),
(3, 'phone', NULL, 1, 'approved', 0, 2),
(4, 'address', NULL, 1, 'approved', 0, 1),
(5, 'onlinep', NULL, 1, 'approved', 0, 2),
(6, 'academic', NULL, 1, 'approved', 0, 3),
(7, 'memb', NULL, 1, 'approved', 0, 4),
(8, 'edit', NULL, 1, 'approved', 0, 5),
(9, 'work', NULL, 1, 'approved', 0, 6),
(10, 'spon', NULL, 1, 'approved', 0, 7),
(11, 'jour', NULL, 1, 'approved', 0, 8),
(12, 'conf', NULL, 1, 'approved', 0, 8),
(13, 'trai', NULL, 1, 'approved', 0, 9),
(14, 'expe', NULL, 1, 'approved', 0, 10),
(15, 'subj', NULL, 1, 'approved', 0, 11),
(16, 'refe', NULL, 1, 'approved', 0, 12),
(17, 'unde', NULL, 1, 'approved', 0, 13),
(18, 'jobs', NULL, 1, 'approved', 0, 14);

-- --------------------------------------------------------

--
-- Table structure for table `login_data`
--

CREATE TABLE IF NOT EXISTS `login_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'user',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `login_data`
--

INSERT INTO `login_data` (`id`, `email`, `password`, `type`, `visible`) VALUES
(1, 'h@mail.com', '123', 'user', 1),
(2, 'r@mail.com', '123', 'user', 1),
(3, 'u@mail.com', '123', 'user', 1);

-- --------------------------------------------------------

--
-- Table structure for table `memb`
--

CREATE TABLE IF NOT EXISTS `memb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `memb`
--

INSERT INTO `memb` (`id`, `value`, `entryid`) VALUES
(1, 'Life time member of Cryptology Research Society of India, ISI, Kolkata.', 64),
(2, 'member of Cryptology Research Society of India', 65),
(3, 'Cryptology', 66),
(4, 'Cryptology', 70),
(5, 'Cryptology', 71),
(6, 'Cryptology', 72),
(7, 'Cryptologyy', 73),
(8, 'Cryptology nbf jdt.kujhgjh mdfcdbgfsbdsnjytekytlipo 8p0p976 u57trmg', 74);

-- --------------------------------------------------------

--
-- Table structure for table `name`
--

CREATE TABLE IF NOT EXISTS `name` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `initial` varchar(10) DEFAULT NULL,
  `fname` varchar(25) NOT NULL,
  `mname` varchar(20) DEFAULT NULL,
  `lname` varchar(25) DEFAULT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `name`
--

INSERT INTO `name` (`id`, `initial`, `fname`, `mname`, `lname`, `entryid`) VALUES
(1, 'Mrsb', 'asin', 'Kumarib', 'ritesh', 13),
(2, 'Mrsb', 'asin', 'Kumarib', 'ritesh', 14),
(3, 'q', 'q', 'q', 'q', 15),
(4, '', '', '', '', 16),
(5, 'jyu', '', '', '', 17),
(6, 'jyu', 'lk', 'lk', 'ut', 18),
(8, 'mr', 'sus', 'in', 'ja', 21),
(9, 'mr', 'sus', '', 'ja', 27),
(17, 'Mr', 'Rakesh', 'Kumar', 'sharma', 0);

-- --------------------------------------------------------

--
-- Table structure for table `onlinep`
--

CREATE TABLE IF NOT EXISTS `onlinep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL COMMENT 'email/url',
  `value` varchar(100) NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `onlinep`
--

INSERT INTO `onlinep` (`id`, `type`, `value`, `entryid`) VALUES
(1, 'email', 'sfd1', 59),
(2, 'email', 'sf12', 60),
(3, 'email', 'vgdn3', 61);

-- --------------------------------------------------------

--
-- Table structure for table `pape`
--

CREATE TABLE IF NOT EXISTS `pape` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `phone`
--

CREATE TABLE IF NOT EXISTS `phone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(15) NOT NULL,
  `type` varchar(10) NOT NULL DEFAULT 'Mobile',
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `phone`
--

INSERT INTO `phone` (`id`, `value`, `type`, `entryid`) VALUES
(1, '9874563210', 'mobile', 31),
(2, '', '', 52),
(3, '07458225489', 'office', 63),
(4, '9874563210', 'Mobile', 19);

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--

CREATE TABLE IF NOT EXISTS `photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `caption` varchar(60) DEFAULT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pob`
--

CREATE TABLE IF NOT EXISTS `pob` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pob`
--

INSERT INTO `pob` (`id`, `city`, `state`, `entryid`) VALUES
(1, 'kek', 'raj', 20),
(2, 'ekek', 'raa', 22),
(3, 'ekek', 'raa', 28),
(4, 'kota', 'ooo', 45);

-- --------------------------------------------------------

--
-- Table structure for table `refe`
--

CREATE TABLE IF NOT EXISTS `refe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `refe`
--

INSERT INTO `refe` (`id`, `value`, `entryid`) VALUES
(1, '', 75);

-- --------------------------------------------------------

--
-- Table structure for table `spon`
--

CREATE TABLE IF NOT EXISTS `spon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `subj`
--

CREATE TABLE IF NOT EXISTS `subj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `trai`
--

CREATE TABLE IF NOT EXISTS `trai` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `unde`
--

CREATE TABLE IF NOT EXISTS `unde` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `work`
--

CREATE TABLE IF NOT EXISTS `work` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text NOT NULL,
  `entryid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `entryid` (`entryid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `work`
--

INSERT INTO `work` (`id`, `value`, `entryid`) VALUES
(1, 'Organized a one week Faculty Development Programme on Optimization Techniques using Nature Inspired Algorithms from 19th to 23th Jan, 2015 at Rajasthan Technical University, Kota.', 67),
(2, 'hiiiii', 68);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
