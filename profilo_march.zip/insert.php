<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form id="form1" name="form1" method="post" action="insert1.php">
  <h1>Personal Details</h1>
  <p>
    <label for="T1">Initial</label>
    <input type="text" name="T1" id="T1" />
  </p>
  <p>First Name
    <label for="T2"></label>
    <input type="text" name="T2" id="T2" />
  </p>
  <p>Middle Name
    <label for="T3"></label>
    <input type="text" name="T3" id="T3" />
  </p>
  <p>Last Name
    <label for="T4"></label>
    <input type="text" name="T4" id="T4" />
  </p>
  <p>Where were you born?<input name="hide1" type="checkbox"  value="hide" />
  hide<br>
	
    <label for="T4">City</label>
    <input type="text" name="T5" id="T5" />
  </p>
  <p>
    <label for="T4">State</label>
    <input type="text" name="T6" id="T6" />
  </p>
  <p>DOB
    <input type="text" name="T7" id="T7" />
    <input name="hide2" type="checkbox"  value="hide" />
  hide</p>
  <p>Email
    <input onclick ="addchild('emlist')" type="Button" name="plusemail" id="plusemail" value="+" />
    <ul id="emlist"><li><input onclick ="removeself(this)" type="Button" name="minusitem[]" id="minusitem" value="-" /><input type="text" name="T8[]" id="T8" /><input name="hide3[]" type="checkbox" onclick="upd_text(this,'em')" value="hide" />hide<input style="visibility:hidden;" type="text" name="hideem[]" id="hideem[]" value="show"/></li></ul>
  </p>
<script>
   function addchild(listn){ 
  var itm=document.getElementById(listn).lastChild;
  var ln= itm.cloneNode(true);
  document.getElementById(listn).appendChild(ln);
  //console.log(document.body.childNodes.length);
  }
  function removeself(p){
  //console.log(p.parentNode.parentNode.childNodes.length);
    if(p.parentNode.parentNode.childNodes.length>1)
  p.parentNode.remove();
  }
function upd_text(thiss,type){
    //console.log(thiss.value);
    if(thiss.checked==true)
      {//console.log("made true");
        thiss.nextSibling.nextSibling.value="hide";
      }
    else
      {//console.log("made false");
      thiss.nextSibling.nextSibling.value="show";}
}

  </script>
  <p>Mobile
    <input onclick ="addchild('moblist')" type="Button" name="plusmob" id="plusmob" value="+" />
    <ul id="moblist"><li><input onclick ="removeself(this)" type="Button" name="minusitem[]" id="minusitem" value="-" /><input type="text" name="T9[]" id="T9" /><input name="hide4[]" type="checkbox" onclick="upd_text(this,'mob')" value="hide" />hide<input style="visibility:hidden;" type="text" name="hidemob[]" id="hidemob[]" value="show"/></li></ul>
    </p>
 <p>Where do you live?<input name="hide5" type="checkbox"  value="hide" />
  hide<br> 
 <p>Line1 
   <input type="text" name="T10" id="T10" />
 </p>
 <p>Line2 
   <input type="text" name="T11" id="T11" />
 </p>
 <p>City 
   <input type="text" name="T12" id="T12" />
 </p>
 <p>Pincode 
   <input type="text" name="T13" id="T13" />
 </p>
 <p>State 
   <input type="text" name="T14" id="T14" />
 </p>
 <p>Type 
   <select name="typead" >
   <option>Permanent</option>
   <option>Temporary</option>
   </select>
 </p>
 </p>

  <h1>Academic Details
  </h1>
  <p><input name="hide6" type="checkbox"  value="hide" />hide<br>
  
  <p>Exam 
    <input type="text" name="T15" id="T15" />
  </p>
  <p>Year 
    <input type="text" name="T16" id="T16" />
  </p>
  <p>Board/University 
    <input type="text" name="T17" id="T17" />
  </p>
  <p>Marks Obtained 
    <input type="text" name="T18" id="T18" />
  </p>
<p>Result 
    <input type="text" name="T19" id="T19" />
  </p>  
<p>
    <input type="submit" name="B1" id="B1" value="Submit" />
  </p>
  </form>
</body>
</html>