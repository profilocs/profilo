<?php
function updateentry($uid, $type, $visible, $arg)
{


	//check karo ki uid & type.. phle se koi entry hai kya entries m.. (kuch types ke liy hi hogi)

	$eid= entry($uid, $type, $visible);
	//echo $eid;
	edit($eid, $type, $arg);
}

function entry($uid, $type, $visible)
{
	$q1="insert into entries(uid, type , visible) values('$uid','$type','$visible')";
	echo $q1;
	mysql_query($q1);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
	$q2="select LAST_INSERT_ID()";
	$r=mysql_query($q2);
	$row=mysql_fetch_array($r);
	$id=$row["LAST_INSERT_ID()"];
	//echo $id;
	return $id;
}
function insertname($eid,$initial,$fname,$mname,$lname)
{
	$query="INSERT INTO `name`(`initial`, `fname`, `mname`, `lname`, `entryid`) VALUES ('$initial','$fname','$mname','$lname','$eid') ON DUPLICATE KEY UPDATE initial = '$initial', fname = '$fname', mname = '$mname' , lname = '$lname'";
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
	//$query="UPDATE name SET initial='$initial',fname='$fname',mname='$mname',lname='$lname',entryid='$eid'";

	//INSERT INTO name  (`initial`, `fname`, `mname`, `lname`, `entryid`) VALUES ('a','v','c','s',13) ON DUPLICATE KEY UPDATE initial = 'a', fname = 'v', mname = 'c' , lname = 's'
}
function insertphone($eid,$value,$typephone)
{
	$query="INSERT INTO `phone`(`value`, `type`, `entryid`) VALUES ('$value','$typephone','$eid') ON DUPLICATE KEY UPDATE value = '$value', type = 'typephone'";
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function insertaddress($eid,$line1,$line2,$city,$pin,$state,$typead)
{
	$query="INSERT INTO `address`(`line1`, `line2`, `city`, `pincode`, `state`, `type`, `entryid`) VALUES ('$line1','$line2','$city','$pin','$state','$typead','$eid') ON DUPLICATE KEY UPDATE line1 = '$line1', line2 = '$line2', city = '$city, pincode = '$pincode', state = '$state', type = '$typead'";
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function insertdob($eid,$value)
{
	$query="INSERT INTO `dob`(`value`, `entryid`) VALUES ('$value','$eid') ON DUPLICATE KEY UPDATE value = '$value'";
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function insertonlinep($eid,$value,$typeop)
{
	$query="INSERT INTO `onlinep`(`type`, `value`, `entryid`) VALUES ('$typeop','$value','$eid') ON DUPLICATE KEY UPDATE type = '$typeop', value = '$value'";
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function GetImageExtension($imagetype)
{
	if(empty($imagetype)) return false;
	switch($imagetype)
	{
		case 'image/bmp': return '.bmp';
		case 'image/gif': return '.gif';
		case 'image/jpeg': return '.jpg';
		case 'image/png': return '.png';
		default: return false;
	}
}
function insertphoto($eid,$value,$caption)
{
	$query="INSERT INTO `photo`(`value`, `caption`, `entryid`) VALUES ('$value','$caption','$eid') ON DUPLICATE KEY UPDATE value = '$value', caption = '$caption'";
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function insertpob($eid,$city,$state)
{
	$query="INSERT INTO `pob`(`city`, `state`, `entryid`) VALUES ('$city','$state','$eid') ON DUPLICATE KEY UPDATE city = '$city', state = '$state'";
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function insertacademic($eid,$exam,$year,$board_uni,$result,$remarks)
{
	$query="INSERT INTO `academic`(`exam`, `year`, `board_uni`, `result`, `remarks`, `entryid`) VALUES ('$exam','$year','$board_uni','$result','$remarks','$eid') ON DUPLICATE KEY UPDATE exam = '$exam', year = '$year', board_uni = '$board_uni', result = '$result' remarks = '$remarks'";
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function insertdownloads($eid,$title,$link)
{
	$query="INSERT INTO `downloads`(`title`, `link`, `entryid`) VALUES ('$title','$link', '$eid') ON DUPLICATE KEY UPDATE title = '$title', link = '$link'";
	echo $query;
	mysql_query($query);
	$n=mysql_affected_rows();
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function insertetc($eid,$value,$table)
{
	$query="INSERT INTO `".$table."` (`value`,`entryid`) VALUES ('$value','$eid') ON DUPLICATE KEY UPDATE value = '$value'";
	mysql_query($query);
	$n=mysql_affected_rows();
	//echo "aff".$n;
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function userExists($uid)
{
	$query="SELECT type from login_data where id='$uid' and visible=1";
	$r=mysql_query($query);
	$p=mysql_num_rows($r);
	//$p=1;//remove this when user are logged in
	if($p==1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
function fetchg($what,$i)
{
	$q11="Select name,descri,count_sh";
	switch($what)
	{
		case "headings":
		$q14=$q12="";break;
		case "subheadings":
		$q12=",attached";
		$q14=" and attached='$i'";break;
	}
	$q13=" from list_".$what." where visible=1";
	$q1=$q11.$q12.$q13.$q14;
	//echo $q1;//kachra kam ho gya
		$r=mysql_query($q1);
		//echo mysql_num_rows($r);
		$list=array();
		while($row=mysql_fetch_array($r))
		{
			array_push($list,$row);
		}
		return $list;
}
function fetchkey($what, $whose, $vis)
{
		$q1="Select * from entries where type='$what' and uid='$whose'";
		$r=mysql_query($q1);
		$list=array();
		while($row=mysql_fetch_array($r))
		{
			if($vis==0)
			{
				$q2="select * from ".$row["type"]." where entryid=".$row["id"];
				
				$b=mysql_query($q2);
				$row1=mysql_fetch_array($b);
				array_push($row1, $row);
				//echo json_encode($row1);
				array_push($list, $row1);
			}
			else
			{
				if($row["visible"]==1)
				{
					$q2="select * from ".$row["type"]." where entryid=".$row["id"];
					
					$b=mysql_query($q2);
					$row1=mysql_fetch_array($b);
					array_push($row1, $row);
					//echo json_encode($row1);
					array_push($list, $row1);
					
				}
			}
			
		}
		return $list;
}
function togglevis($eid)
{
	mysql_query("UPDATE entries SET visible = IF(visible=1, 0, 1) where id = $eid");
	$n=mysql_affected_rows();
	
	if($n<1)
	{
		echo "Error:Saving Data";
		die();
	}
}
function login($uname,$pswd)
{
	$query="select * from login_data where email='$uname' and password='$pswd'";
	$r1=mysql_query($query);
	$n=mysql_num_rows($r1);
	$row=mysql_fetch_array($r1);
	//die();
	if($n==1)
	{
		return $row["id"];
	}
}
function edit($eid, $type, $arg)
{
	switch($type)
	{
		case "name" :
		insertname($eid,$arg["initial"],$arg["fname"],$arg["mname"],$arg["lname"]);
		break;
		case "phone" :
		insertphone($eid,$arg["value"],$arg["typephone"]);
		break;
		case "address" :
		insertaddress($eid,$arg["line1"],$arg["line2"],$arg["acity"],$arg["pin"],$arg["astate"],$arg["atype"]);
		break;
		case "dob" :
		insertdob($eid,$arg["value"]);
		break;
		case "onlinep" :
		insertonlinep($eid,$arg["value"],$arg["typeop"]);
		break;
		case "photo" :
		insertphoto($eid,$arg["value"],$arg["caption"]);
		break;
		case "pob" :
		insertpob($eid,$arg["city"],$arg["state"]);
		break;
		case "academic" :
		insertacademic($eid,$arg["exam"],$arg["year"],$arg["board_uni"],$arg["result"],$arg["remarks"]);
		break;
		case "downloads" :
		insertdownloads($eid,$arg["title"],$arg["link"]);
		break;
		case "memb" :
		case "edit" :
		case "work" :
		case "spon" :
		case "jour" :
		case "conf" :
		case "trai" :
		case "expe" :
		case "subj" :
		case "refe" :
		case "unde" :
		case "jobs" :
		insertetc($eid,$arg["data"],$type);
		break;
		
	}
	
}
?>