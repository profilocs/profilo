<?php
require_once "mylibrary.php";
require_once "functions.php";

if(isset($_GET["user"]))
{
	$uid=$_GET["user"];
	if(userExists($uid))
	{
		$editor=0;
		$GLOBALS['show_login_logout'] = "login";

		session_start();
		//echo json_encode($_SESSION);
		if(isset($_SESSION["logged"]))
		{
			if($_SESSION["logged"]=="in")
			{
				if(isset($_SESSION["uid"]))
				{
					$GLOBALS['show_login_logout'] = "logout";
					$loggedInUserId = $_SESSION["uid"];
					if ($uid==$loggedInUserId)
					{
						$editor=1;

						//dher saare if if if aayenge...
						// saari edit delete requests yhi aayngi
						if(isset($_POST["editnameS"])){
							echo "edit name requested";
							echo "edit submit success.. try refresh if result not appear";
							edit($_REQUEST["entryid"],'name',$_REQUEST);
						}
						if (isset($_POST["childS"])) {
							updateentry($loggedInUserId,$_REQUEST["shtype"],$_REQUEST["vis"],$_REQUEST);
						}
						if (isset($_POST["editaS"])) {
							edit($_REQUEST["eid"],$_REQUEST["shtype"],$_REQUEST);
						}
						if (isset($_POST["hideS"])) {
							togglevis($_REQUEST["eid"]);
						}
						if (isset($_POST["unhideS"])) {
							togglevis($_REQUEST["eid"]);
						}
						if (isset($_POST["picS"])) {
							$file_name=$_FILES["value"]["name"];
							$temp_name=$_FILES["value"]["tmp_name"];
							$imgtype=$_FILES["value"]["type"];
							$ext= GetImageExtension($imgtype);
							$imagename=date("d-m-Y")."-".time().$ext;
							$target_path = "images/".$imagename;
							if ($_FILES["value"]["size"]<=1000000) {
								if(move_uploaded_file($temp_name, $target_path)) {
								$_REQUEST["value"]=$imagename;
								updateentry($loggedInUserId,'photo',1,$_REQUEST);
								}
							} else {
								echo "<br>file size <strong>must be less than or equal to 1MB</strong>.";
								echo "<br>we <strong>suggest</strong> you to keep file size around 300 KB to optimize speed with quality.";
								echo "<br>File upload failed!!";
							}
							
							
							
						}
						if (isset($_POST["dlS"])) {
							$file_name=$_FILES["value"]["name"];
							//echo $file_name;
							$temp_name=$_FILES["value"]["tmp_name"];
							//echo $temp_name;
							$filetype=$_FILES["value"]["type"];
							//$ext= GetImageExtension($filetype);
							$filename=date("d-m-Y")."-".time().$file_name;
							$target_path = "downloads/".$filename;
							if ($_FILES["value"]["size"]<=10000000) {
								if(move_uploaded_file($temp_name, $target_path)) {
								$_REQUEST["link"]=$target_path;
								updateentry($loggedInUserId,'downloads',1,$_REQUEST);
								}
							} else {
								echo "<br>file size <strong>must be less than or equal to 10 MB</strong>.";
								echo "<br>we <strong>suggest</strong> you to keep file size around 300 KB to optimize speed with quality.";
								echo "<br>File upload failed!!";
							}
							
							
							
						}
						if (isset($_POST["LogOutS"])) {
							echo "logoutsubmitted";
							$_SESSION["logged"]="out";
							session_unset();
							$GLOBALS['show_login_logout'] = "login";
							echo "--what shows?".$GLOBALS['show_login_logout'];
							//session unset destroy and redirect page
							//all three tasks compulsory
							//$show login
						}
					}//no editor, viewer logged in
					else
					{
						//show a link "my profile"
					}
					//$GLOBALS['show_login_logout'] = "logout";
				}//login but no uid
				else
				{
					//login fail or expire, login again
					$GLOBALS['show_login_logout'] = "login";
				}
			}//logged out, a viewer
			else
			{
				$GLOBALS['show_login_logout'] = "login";
				if(isset($_POST["LogInS"]))
				{
					echo "login submitted";
					if(login($_POST["uname"],$_POST["pswd"])!=0)
					{
						$_SESSION["logged"]="in";
			
						$_SESSION["uid"] = login($_POST["uname"],$_POST["pswd"]);
						//bjay below code ke redirect page
						$loggedInUserId = $_SESSION["uid"];
						echo "---login success";
						echo "---logged in user".$_SESSION["uid"];
			
					}
					else
					{
						echo "---login failure";
					}
				}
			}
		}//no session
		else
		{
			if(isset($_POST["LogInS"]))
			{
				echo "login submitted2";
				if(login($_POST["uname"],$_POST["pswd"])!=0)
				{
					$_SESSION["logged"]="in";
		
					$_SESSION["uid"] = login($_POST["uname"],$_POST["pswd"]);
					//bjay below code ke redirect page
					$loggedInUserId = $_SESSION["uid"];
					echo "---login success";
					$GLOBALS['show_login_logout']="logout";
					echo "---logged in user".$_SESSION["uid"];
		
				}
				else
				{
					echo "---login failure";
				}
			}
		}
		//echo json_encode($_SESSION);
		//start displaying profile
		//here
		//fetch name
		///////////show login or logout form here
		$fullname = fetchkey('name',$uid,1);
		$nameps= array('','','','','','','');
		echo "<html><head><link href='profile.css' rel='stylesheet' type='text/css' /><link href='table.css' rel='stylesheet' type='text/css' /><link href='scrollbar.css' rel='stylesheet' type='text/css' /><script type='text/javascript' src='pro_script.js'></script><title>";
	  //Profilo : soon</title>
	//</head>
		//echo "size name ".sizeof($fullname);
		if (sizeof($fullname)<=0)
		{
			//set title of html
			echo "Unpublished User</title></head><body>";
			echo "<br>User exists but has not published his/her profile yet so unable to display it <br>if u r viwer get back soon, if u know him/her suggest to login and update <br>if u r this user login now and update<br>";
			//store this above string in some variable and later print it when you need it
			//echo "</body></html>";
			if ($editor==1)
			{
				//show add name form- submit
			}
		}//published user, atleast has a name added
		else
		{
			//set title of html
			//display name
			$row = $fullname[0];
			echo $row["initial"]." ".$row["fname"]." ".$row["mname"]." ".$row["lname"]." : Profilo";
			echo "</title></head>";
			echo "<body style='overflow-y: hidden;' onload=\"docLoad('section')\">";
			//sanjay file
			?>
			<div id="main">
			<!-------------- Here Header Part Start ---------------->
			<header id="head">
			
				<div id="logo">
					
				</div>
			 
				<div id="person_name">
				
					<?php
					echo "<p><h4> Name: ".$row["initial"]." ".$row["fname"]." ".$row["mname"]." ".$row["lname"]."</h4></p>";
					if ($editor)
					{
						?>
						<script>
						var nameps = <?php echo json_encode($row); ?>;
						</script>
						<?php
						echo "<p onClick=\"Show(['editnameform',nameps])\" style='cursor: pointer;'>Show Edit name form</p><div id='editnameform_container'></div>";
					}
					?>
				</div> 
				
				<div id="person_photo">
				
				</div>
				<div id="head_login">
					<?php
					echo "--what shows?2".$GLOBALS['show_login_logout'];
					if($GLOBALS['show_login_logout']=="login")
					{
						echo "<button id='login_hide' onClick=\"Show(['loginform'])\" style='cursor: pointer;'>Login</button><div id='loginform_container'></div>";
					}
					if($GLOBALS['show_login_logout']=="logout")
					{
						echo "<form method='post' id='logoutform'><input name='LogOutS' type='submit' value='Log Out'></form>";
					}
					echo "<a href='pro1.php?user=$uid&action=downloads' ><li>downloads</li></a>";
					?>
				</div>
			</header>
			<!--------------- Here Header Part End ------------------>
			
			<div id="center_contain">
			<!---------------- Here Aside_Menu Part Start ---------------->
		
				<div id="menus">
					<ul>
						<?php
						if (isset($_GET["action"])) {
							if ($_GET["action"]=="downloads") {
								echo "<a href='pro1.php?user=$uid' ><li>(-)profile</li></a>";
							}
						}
						else
						{
							$h1 = fetchg('headings',0);
							for($i=0;$i<sizeof($h1);$i++)
							{
								echo "<li>".$h1[$i]["name"]."</li>";
							}
						}
						?>
					</ul>
				</div>

				<!------------------- Here Aside_Menu Part End -------------->
				<!------------------- Here Section Part Start ------------>
				
				<section id="section">
					<div id="content" onscroll="fScroll(this)">
						<?php if (isset($_GET["action"])) {
							if ($_GET["action"]=="downloads") {
								echo "downloads downloads";
								//show a table from downloads so viewer can download or refer to links
								//editor==1; updateble deletable..
								if ($editor==1)
								{	
								
								echo "<form method='post' enctype='multipart/form-data'>
									<input type='file' name='value'>
									<input type='text' name='title' placeholder='title'>
									<input type='submit' name='dlS' value='Upload'>
								</form>";
								}
								if ($editor==1)
								{	
									$dlist = fetchkey('downloads', $uid,0);
								}
								else
								{
									$dlist = fetchkey('downloads', $uid,1);
								}
								
								//echo json_encode($dlist);
								echo "<table border='1'>";
								echo "<thead><td>Sr.</td><td>";
								echo (sizeof($dlist)==0) ? "No Entries yet!! " : ((sizeof($dlist)==1) ? "1 Entry" : sizeof($dlist)." Entries");
								if($editor==1)
									echo " Add one now..<input onclick =\"addedit('add','downloads')\" type='Button' name='plusdl' id='plusdl' value='+' />";
								echo "</td>";
								if($editor==1)
									echo "<td>Actions</td>";
								echo "</thead>";
								echo "<tbody>";
								for($k=0;$k<sizeof($dlist);$k++)
								{
									echo "<tr>";
									echo "<td>dl".($k+1).".</td><td><a href='".($dlist[$k]["link"])."' >".($dlist[$k]["title"])."</a></td>";
									//if editor on then actions actions actions actions actions actions actions actions actions actionsactions actionsactionsactionsactions 
									if($editor==1)
									{
										
										echo "<td><button name='editS' value='Edit' onClick=\"addedit('edit',['".$dlist[$k]["entryid"]."','downloads','".$dlist[$k]["link"]."'])\">Edit</button> ";
										
										if ($dlist[$k][5]["visible"]==1)//4 because, no. of columns in key-tables is 4 (last added link col)
										{
											echo "| <form method='post' id='hideform'><input type='hidden' name='eid' value='".$dlist[$k]["entryid"]."'><input name='hideS' type='submit' value='Hide'></form>";
										}
										else
										{
											echo " | <form method='post' id='unhideform'><input type='hidden' name='eid' value='".$dlist[$k]["entryid"]."'><input name='unhideS' type='submit' value='Unhide'></form>";
										}
										echo " </td>";
									}
									echo "</tr>";
								}
								if($editor==1)
								{
									echo "<tr><td>".($k+1).".</td><td><form method='post' id='add_downloads' style='display:none;'><input type='hidden' name='shtype' value='downloads'><input type='text' name='data' size='100%'><input type='radio' name='vis' value='1' checked>show<input type='radio' name='vis' value='0'>hide<input type='submit' name='childS' value='save'><input type='button' onClick=\"addedit('add','downloads')\" value='cancel'></form>";
									echo "<div id='downloadsform_container'></div></td></tr>";
								}
								echo "</tbody>";
								echo "</table>";
							}
						}
						else
							{
								?>
						<p><h4 id="profile3_show">Name :
							<?php echo $row["initial"]." ".$row["fname"]." ".$row["mname"]." ".$row["lname"];
							?>
						</h4></p>

						<?php

						//$h1 = fetchg('headings',0);
						for($i=0;$i<3;$i++)
						{
							?>
							<p id="infotag">
							<?php echo $h1[$i]["name"]; ?>
							</p>
							<?php echo "wait karo ...";
						}
						?>
						<form method="post" enctype="multipart/form-data">
							<input type="file" name="value">
							<input type="text" name="caption">
							<input type="submit" name="picS" value="save">
						</form>
						<?php
						for($i=0;$i<sizeof($h1);$i++)
						{
							?>
							<p id="infotag">
							<?php echo $h1[$i]["name"]; ?>
							</p>
							<?php
							$h2 = fetchg('subheadings',$i+1);
							$j=0;
				
							while($j<sizeof($h2))
							{
								echo "<table border='1'>";
								//if (sizeof($h2)>1)
								//{
									echo "<thead><td>Sr.</td><td>";
									if ($editor==1)
									{
										$key[$j]=fetchkey($h2[$j]["name"],$uid,0);
									}
									else
									{
										$key[$j]=fetchkey($h2[$j]["name"],$uid,1);
									}
									

									echo (sizeof($key[$j])==0) ? "No Entries yet!! " : ((sizeof($key[$j])==1) ? "1 Entry" : sizeof($key[$j])." Entries");
									if($editor==1)
										echo " Add one now..<input onclick =\"addedit('add','".strtolower(substr($h2[$j]["name"], 0, 4))."')\" type='Button' name='plusemail' id='plusemail' value='+'' />";
									echo "</td>";
									if($editor==1)
										echo "<td>Actions</td>";
									echo "</thead>";
								//}
									
								echo "<tbody>";
								
								//echo "sizeof".sizeof($key[$j]);
								//echo "<br>".json_encode($key);
								//echo "<tr>";
								for($k=0;$k<sizeof($key[$j]);$k++)
								{
									if($h2[$j]["name"]=="dob")
									{
										$h2[$j]["name"]="Date of Birth";
									}
									else if($h2[$j]["name"]=="pob")
									{
										$h2[$j]["name"]="Place of Birth";
										//$asd = 
									}
									else if($h2[$j]["name"]=="phone")
									{
										$h2[$j]["name"]="Phone Number";
									}
									else if($h2[$j]["name"]=="photo")
									{
										$h2[$j]["name"]="pic";
										$key[$j][$k]["value"] = "images/".$key[$j][$k]["value"];
									}
									//echo $h2[$j]["name"].":::--";
									if ($h2[$j]["name"]=="pic") {
										echo "<img src='".$key[$j][$k]["value"]."' alt='".$key[$j][$k]["caption"]."' style='height:200px'/>";
									}
									else
									echo "<tr><td>".$h2[$j]["name"].($k+1).".</td><td>".json_encode($key[$j][$k]["value"])."</td>";
									//if editor on then actions actions actions actions actions actions actions actions actions actionsactions actionsactionsactionsactions 
									if($editor==1)
									{
										
										echo "<td><button name='editS' value='Edit' onClick=\"addedit('edit',['".$key[$j][$k]["entryid"]."','".$h2[$j]["name"]."','".$key[$j][$k]["value"]."'])\">Edit</button> ";
										$len=sizeof($key[$j][$k]);
										//echo "lrnnnngth".$len;
										if ($key[$j][$k][4]["visible"]==1)//4 because, no. of columns in key-tables is 4 (last added link col)
										{
											echo "| <form method='post' id='hideform'><input type='hidden' name='eid' value='".$key[$j][$k]["entryid"]."'><input name='hideS' type='submit' value='Hide'></form>";
										}
										else
										{
											echo " | <form method='post' id='unhideform'><input type='hidden' name='eid' value='".$key[$j][$k]["entryid"]."'><input name='unhideS' type='submit' value='Unhide'></form>";
										}
										echo " </td>";
									}//addedit('edit',['".$key[$j][$k]["id"]."','."$h2[$j]["name"]."'])
									echo "</tr>";
								}
								if($editor==1)
								{
									echo "<tr><td>".($k+1).".</td><td><form method='post' id='add_".$h2[$j]["name"]."' style='display:none;'><input type='hidden' name='shtype' value='".$h2[$j]["name"]."'><input type='text' name='data' size='100%'><input type='radio' name='vis' value='1' checked>show<input type='radio' name='vis' value='0'>hide<input type='submit' name='childS' value='save'><input type='button' onClick=\"addedit('add','".strtolower(substr($h2[$j]["name"], 0, 4))."')\" value='cancel'></form>";
									echo "<div id='".$h2[$j]["name"]."form_container'></div></td></tr>";
								}
								echo "</tbody></table>";
								$j++;
							}
						}
						}?>
					</div>
				</section>
					   
				<!-------------------   Here Section Part End ---------------------->
				   
			</div>
			<!------------  Here Center_Contain Ends  --------------------->
			<!-------------------   Here Footer Part  Start ---------------------->
			<footer>powered by profilo
			</footer>
			<!--------------------   Here Footer Part End -------------------------->
		</div><!--here main ends-->
			<?php
			//profile complete
			//echo "</body></html>";
			  

		}
		
		echo "</body></html>";
		

	}//no such user
	else
	{
		echo "No Such User Exists";
	}
}//no user selected
else
{
	echo "Go Back and Select a User";
	echo "<br>temporarily <a href='pro1.php?user=1'>click here(1)</a>";
	echo "<br>or <a href='pro1.php?user=2'>here(2)</a>";
	echo "<br>or <a href='pro1.php?user=3'>here(3)</a>";
}

?>