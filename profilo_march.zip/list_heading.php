<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
$cn=mysql_connect("localhost","root","");
if(!$cn)
{
	echo "Unable to connect";
	die();
}
$db=mysql_select_db("profilo_db",$cn);
if(!$db)
{
	echo "Database does not exist";
	die();
}
$q="select * from list_headings";
$r=mysql_query($q,$cn);
while($row=mysql_fetch_array($r))
{
	// fetch data from row
	$id=$row["id"];
	$name=$row["name"];
	$descri=$row["descri"];
	$visible=$row["visible"];
	$status=$row["status"];
	$count_sh=$row["count_sh"];
}
?>

<p>Id : <?php echo $id; ?></p>
<p>Name : <?php echo $name; ?></p>
<p>Description : <?php echo $descri; ?></p>
<p>Visible : <?php echo $visible; ?></p>
<p>Status : <?php echo $status; ?></p>
<p>Count : <?php echo $count_sh; ?></p>

</body>
</html>