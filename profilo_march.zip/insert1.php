<?php
require_once "mylibrary.php";
require_once "functions.php";
$uid=1;//remove when login givs uid


print_r($_POST);

$initial=$_REQUEST["T1"];
$fname=$_REQUEST["T2"];
$mname=$_REQUEST["T3"];
$lname=$_REQUEST["T4"];
$arg = compact(array("initial","fname","mname","lname"));
//print_r($args);

$type="name";
$visible=1; //form se lena hai

//updateentry($uid, $type, $visible, $arg);

$city=$_REQUEST["T5"];
$state=$_REQUEST["T6"];
$pobvis=1;
if(isset($_REQUEST["hide1"]))
$pobvis=0;
echo $pobvis;
$arg = compact(array("city","state"));
$type="pob";
//updateentry($uid, $type, $pobvis, $arg);

$dob=$_REQUEST["T7"];
$dobvis=1;
if(isset($_REQUEST["hide2"]))
$dobvis=0;
$arg = compact(array("dob"));
$type="dob";
//updateentry($uid, $type, $dobvis, $arg);

$email_list=$_REQUEST["T8"];
$emailvis=$_REQUEST["hideem"];
echo "emial length is ".sizeof($email_list)."<br>asd<br>";
for($i=0;$i<sizeof($email_list);$i++)
{
	$value=$email_list[$i];
	$typeop="email";
	$mailvis=1;
	//echo "email ".$i."th is ".$email[$i]."<br>";
	//if(isset($_REQUEST["hide3"]))
	if ($emailvis[$i]=="hide") {
		$mailvis=0;
	}
	$arg = compact(array("value","typeop"));
	$type="onlinep";
	//updateentry($uid, $type, $mailvis, $arg);
}

$mob_list=$_REQUEST["T9"];
$mobviss=$_REQUEST["hidemob"];
for($i=0;$i<sizeof($mob_list);$i++)
{
	$value=$mob_list[$i];
	$typephone="personal";
	$mobvis=1;
	if ($mobviss[$i]=="hide") {
		$mobvis=0;
	}
	$arg = compact(array("value","typephone"));
	$type="phone";
	//updateentry($uid, $type, $mobvis, $arg);
}



$line1=$_REQUEST["T10"];
$line2=$_REQUEST["T11"];
$acity=$_REQUEST["T12"];
$pin=$_REQUEST["T13"];
$astate=$_REQUEST["T14"];
$atype=$_REQUEST["typead"];
$addvis=1;
if(isset($_REQUEST["hide5"]))
$addvis=0;
$arg = compact(array("line1","line2","acity","pin","astate","atype"));
$type="address";
//updateentry($uid, $type, $addvis, $arg);


$exam=$_REQUEST["T15"];
$year=$_REQUEST["T16"];
$board_uni=$_REQUEST["T17"];
$remarks=$_REQUEST["T18"];
$result=$_REQUEST["T19"];
$acadvis=1;
if(isset($_REQUEST["hide6"]))
$acadvis=0;
$arg = compact(array("exam","year","board_uni","result","remarks"));
$type="academic";
//updateentry($uid, $type, $acadvis, $arg);





//-------------------------------------------

?>