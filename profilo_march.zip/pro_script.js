function docLoad(divId)
{
	var scx = getCookie("scrollp");
	document.getElementById(divId).scrollTop=scx;
}
function fScroll(val)
{
        //var hidScroll = document.getElementById('body1');
        //hidScroll.value = val.scrollTop;
        console.log(val.scrollTop);

        document.cookie="scrollp="+val.scrollTop;
        //console.log(document.scrollTop);
}
function getCookie(name)
{
  var value = "; " + document.cookie;
  var parts = value.split("; " + name + "=");
  if (parts.length == 2) return parts.pop().split(";").shift();
}
function addedit(act,htype)
{
	//console.log(htype);
	//console.log(act);
	switch(act)
	{
		case 'add':
		var el = document.getElementById("add_"+htype);
		var al = document.getElementById("edit_"+htype);
	if(el.style.display=="none")
	{
		el.style.display="block";
		if (al.style.display=="block") {
			al.parentNode.innerHTML="";
		};
	}
	else
		el.style.display="none";
	break;

	case 'edit':
	console.log(htype);
	fc = document.getElementById(htype[1]+'form_container');
	var form = "<form method='post' id='edit_"+htype[1]+"' style='display:block;'><input type='hidden' name='eid' value='"+htype[0]+"'><input type='hidden' name='shtype' value='"+htype[1]+"'><input type='text' name='data' size='100%' value='"+htype[2]+"'><input type='submit' name='editaS' value='save'><input type='button' onClick=\"addedit('edit',['"+htype[0]+"','"+htype[1]+"','"+htype[2]+"'])\" value='cancel'></form>";
	//console.log(fc);
	
	//document.cookie="editid="+htype[0];
	if((fc.innerHTML==""))
	{
		//console.log((htype[1]));
			if (document.getElementById("add_"+htype[1]).style.display=="block") {document.getElementById("add_"+htype[1]).style.display="none";}
		fc.innerHTML=form;
		document.cookie="edit"+htype[1]+"id="+htype[0];
	}
	else 
	{
		var namet = "edit"+htype[1]+"id";
		var cx = getCookie(namet);
		if(cx==htype[0])
		{
			//console.log("same same");
			fc.innerHTML="";
		}
		else
		{
			fc.innerHTML=form;
			document.cookie="edit"+htype[1]+"id="+htype[0];
		}
	}
	break;
	}
	
}
function Show(type)
{
	/*var el = document.getElementById(type);
	if(el.style.display=="none")
		el.style.display="block";
	else
		el.style.display="none";*/
	//console.log(type[1]);

	fc = document.getElementById(type[0]+'_container');
	switch(type[0])
	{
		case 'loginform':
		if (fc.innerHTML=="")
			fc.innerHTML="<form method='post' id='loginform'><input name='uname' type='text' placeholder='Username'><input name='pswd' type='password' placeholder='Password'><input name='LogInS' type='submit' value='Log in'><input name='cancel_login' onClick=\"hide('loginform')\" type='button' value='cancel'></form>";
		else
			fc.innerHTML="";
		break;

		case 'editnameform':
		nameps = type[1];
		if (fc.innerHTML=="")
			fc.innerHTML="<form method='post' id='editnameform'><input name='entryid' type='hidden' value='"+nameps[5]+"'>Initial<input name='initial' type='text' value='"+nameps[1]+"'>First Name<input name='fname' type='text' value='"+nameps[2]+"'>Middle Name<input name='mname' type='text' value='"+nameps[3]+"'>Last Name<input name='lname' type='text' value='"+nameps[4]+"'><input name='editnameS' type='submit' value='Edit'><input name='cancel_edit' onClick=\"hide('editnameform')\" type='button' value='cancel'></form>";
		else
			fc.innerHTML="";
		break;
	}
	
	
}
function hide(type)
{
	document.getElementById(type+'_container').innerHTML="";
}
