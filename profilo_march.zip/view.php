<?php
require_once "mylibrary.php";
require_once "functions.php";
$uid=$_GET["user"];
viewprofile($uid);
function viewprofile($uid)
{
	$query="SELECT type from login_data where id='$uid' and visible=1";
    $r=mysql_query($query);
    $p=mysql_num_rows($r);
    //$p=1;//remove this when user are logged in
	if($p==1)
	{
		echo "found";
		$q1="select type,id from entries where uid='$uid' and visible='1'";
		$a=mysql_query($q1);
		while($row=mysql_fetch_array($a))
		{
		// fetch data from row
		$type=$row["type"];
		$id=$row["id"];
		$q2="select * from $type where entryid='$id'";
		echo $q2;
		$b=mysql_query($q2);
		echo mysql_num_rows($b);
		echo json_encode(mysql_fetch_array($b));
		echo "<br>"; 
		}
	}
	else
	{
		echo "No such user exists";
	}
	 
}
?>